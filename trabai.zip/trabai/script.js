// script.js

// Exemplo de dados simulados
const demandas = [
  {
    titulo: "Trocar monitor quebrado",
    prioridade: "Media",
    descricao: "O monitor está com a tela preta e não liga."
  },
  {
    titulo: "Trocar monitor quebrado",
    prioridade: "Media",
    descricao: "O monitor está com a tela preta e não liga."
  },
  {
    titulo: "Trocar monitor quebrado",
    prioridade: "Media",
    descricao: "O monitor está com a tela preta e não liga."
  },
  {
    titulo: "Trocar monitor quebrado",
    prioridade: "Media",
    descricao: "O monitor está com a tela preta e não liga."
  },
  {
    titulo: "Trocar monitor quebrado",
    prioridade: "Alta",
    descricao: "O monitor está com a tela preta e não liga."
  },
  {
    titulo: "Instalar software",
    prioridade: "Media",
    descricao: "Preciso do AutoCAD para o setor de engenharia."
  },
  {
    titulo: "Instalar software",
    prioridade: "Baixa",
    descricao: "Preciso do AutoCAD para o setor de engenharia."
  }
  ,
  {
    titulo: "Instalar software",
    prioridade: "Alta",
    descricao: "Preciso do AutoCAD para o setor de engenharia."
  }
];

function renderCards() {
  const container = document.getElementById("dashboard");
  container.innerHTML = "";

  demandas.forEach((demanda) => {
    const card = document.createElement("div");
    card.className = "card";

    // Converte a prioridade para lowercase para usar como classe CSS
    const prioridadeClass = demanda.prioridade.toLowerCase();

    card.innerHTML = `
      <h3>${demanda.titulo}</h3>
      <div class="prioridade ${prioridadeClass}">${demanda.prioridade}</div>
      <p>${demanda.descricao}</p>
    `;

    container.appendChild(card);
  });
}


// Chamada inicial para preencher a tela
renderCards();
