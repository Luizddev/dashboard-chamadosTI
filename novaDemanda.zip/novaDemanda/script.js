const form = document.getElementById("demandaForm");
const nomeSolicitante = document.getElementById("nomeSolicitante");
const erroNome = document.getElementById("erroNome");
const mensagemSucesso = document.getElementById("mensagemSucesso");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const nomeValido = /^[A-Za-zÀ-ÿ\s]+$/.test(nomeSolicitante.value.trim());

  if (!nomeValido) {
    nomeSolicitante.classList.add("error");
    erroNome.style.display = "block";
    mensagemSucesso.style.display = "none";
    return;
  }

  nomeSolicitante.classList.remove("error");
  erroNome.style.display = "none";

  // Simula envio
  mensagemSucesso.style.display = "block";
  form.reset();
});